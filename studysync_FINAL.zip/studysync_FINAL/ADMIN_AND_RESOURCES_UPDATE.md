# Admin and Resources Update

## What changed
- Added seeded overdue-style assignments for every user by inserting past-due pending assignments in `studysync_db.sql`.
- Added seeded resources to `studysync_db.sql` so the Resources page has working records out of the box.
- Generated real files for the seeded resource items under `uploads/resources/`.
- Added `resource_file.php` so files are opened and downloaded through a safe access route.
- Updated `resources.php` so file buttons work for seeded and uploaded files, and admin users can delete any resource.
- Added an `account_role` column to the `users` table and seeded two admin accounts.
- Added `admin.php`, an admin control page for managing users, assignments, resources, courses, study groups, and schedule events.
- Added an Admin link to the sidebar for administrator accounts.

## Seeded admin accounts
- `john.doe@ncu.edu.jm`
- `sam@stu.ncu.edu.jm`

Use the password already defined in your SQL seed for those accounts.
