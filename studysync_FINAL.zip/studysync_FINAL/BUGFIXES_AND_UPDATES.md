# StudySync Updates

## Changes made
1. Fixed the registration terms checkbox by giving it a real form name/id, server-side validation, and working links to the Terms of Service and Privacy Policy pages.
2. Added `terms.php` and `privacy.php` so the user can open those pages from registration.
3. Added clickable priority controls on the Assignments page so priority cycles between High, Medium, and Low.
4. Reworked the Schedule page to include a true monthly timetable view that still shows assignment deadlines inside the month calendar.
5. Added links from monthly timetable items to the related schedule edit or assignment edit page.
6. Added layout rules to keep the left sidebar width consistent across the main signed-in pages.
7. Restored shared helper functions in `config.php` that are used across the project.
8. Corrected schedule event type validation so it matches the project event types used in the form.

## Validation completed
- Ran PHP lint checks on all PHP files successfully.
- Full browser execution was not available in this container because the PHP runtime here does not have the MySQLi extension loaded.
