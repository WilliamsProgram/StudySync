<?php
require_once 'config.php';
requireAdmin($conn);

$user = getUser($conn);
$init = initials($user['first_name'], $user['last_name']);
$adminId = (int) $user['id'];
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfOrDie();
    $action = $_POST['action'] ?? '';

    if ($action === 'set_role') {
        $targetId = cleanInt($_POST['user_id'] ?? 0, 1);
        $role = ($_POST['account_role'] ?? 'student') === 'admin' ? 'admin' : 'student';
        if ($targetId === $adminId && $role !== 'admin') {
            $error = 'You cannot remove your own administrator access.';
        } else {
            $stmt = $conn->prepare('UPDATE users SET account_role = ? WHERE id = ?');
            $stmt->bind_param('si', $role, $targetId);
            $stmt->execute();
            $stmt->close();
            $message = 'User role updated.';
        }
    }

    if ($action === 'delete_user') {
        $targetId = cleanInt($_POST['user_id'] ?? 0, 1);
        if ($targetId === $adminId) {
            $error = 'You cannot delete the account you are currently using.';
        } else {
            $stmt = $conn->prepare('DELETE FROM users WHERE id = ?');
            $stmt->bind_param('i', $targetId);
            $stmt->execute();
            $stmt->close();
            $message = 'User deleted.';
        }
    }

    if ($action === 'update_assignment') {
        $assignmentId = cleanInt($_POST['assignment_id'] ?? 0, 1);
        $status = cleanStatus($_POST['status'] ?? 'pending');
        $priority = cleanPriority($_POST['priority'] ?? 'medium');
        $stmt = $conn->prepare('UPDATE assignments SET status = ?, priority = ? WHERE id = ?');
        $stmt->bind_param('ssi', $status, $priority, $assignmentId);
        $stmt->execute();
        $stmt->close();
        $message = 'Assignment updated.';
    }

    if ($action === 'delete_assignment') {
        $assignmentId = cleanInt($_POST['assignment_id'] ?? 0, 1);
        $stmt = $conn->prepare('DELETE FROM assignments WHERE id = ?');
        $stmt->bind_param('i', $assignmentId);
        $stmt->execute();
        $stmt->close();
        $message = 'Assignment deleted.';
    }

    if ($action === 'update_resource') {
        $resourceId = cleanInt($_POST['resource_id'] ?? 0, 1);
        $title = cleanTitle($_POST['title'] ?? '', 150);
        $resourceType = cleanResourceType($_POST['type'] ?? 'other');
        $isPrivate = isset($_POST['is_private']) ? 1 : 0;
        if ($title === '') {
            $error = 'Resource title is required.';
        } else {
            $stmt = $conn->prepare('UPDATE resources SET title = ?, type = ?, is_private = ? WHERE id = ?');
            $stmt->bind_param('ssii', $title, $resourceType, $isPrivate, $resourceId);
            $stmt->execute();
            $stmt->close();
            $message = 'Resource updated.';
        }
    }

    if ($action === 'delete_resource') {
        $resourceId = cleanInt($_POST['resource_id'] ?? 0, 1);
        $stmt = $conn->prepare('SELECT file_path FROM resources WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $resourceId);
        $resource = fetchSingleRow($stmt);
        if ($resource) {
            $safePath = safeUploadedResourcePath($resource['file_path'] ?? '');
            if ($safePath && file_exists($safePath)) {
                @unlink($safePath);
            }
            $delete = $conn->prepare('DELETE FROM resources WHERE id = ?');
            $delete->bind_param('i', $resourceId);
            $delete->execute();
            $delete->close();
            $message = 'Resource deleted.';
        }
    }

    if ($action === 'delete_course') {
        $courseId = cleanInt($_POST['course_id'] ?? 0, 1);
        $stmt = $conn->prepare('DELETE FROM courses WHERE id = ?');
        $stmt->bind_param('i', $courseId);
        $stmt->execute();
        $stmt->close();
        $message = 'Course deleted.';
    }

    if ($action === 'delete_group') {
        $groupId = cleanInt($_POST['group_id'] ?? 0, 1);
        $stmt = $conn->prepare('DELETE FROM study_groups WHERE id = ?');
        $stmt->bind_param('i', $groupId);
        $stmt->execute();
        $stmt->close();
        $message = 'Study group deleted.';
    }

    if ($action === 'delete_event') {
        $eventId = cleanInt($_POST['event_id'] ?? 0, 1);
        $stmt = $conn->prepare('DELETE FROM schedule_events WHERE id = ?');
        $stmt->bind_param('i', $eventId);
        $stmt->execute();
        $stmt->close();
        $message = 'Schedule event deleted.';
    }
}

$userRows = $conn->query('SELECT id, first_name, last_name, email, programme, account_role, created_at FROM users ORDER BY id ASC')->fetch_all(MYSQLI_ASSOC);
$assignmentRows = $conn->query("SELECT a.id, a.title, a.status, a.priority, a.due_date, CONCAT(u.first_name, ' ', u.last_name) AS owner, c.course_code FROM assignments a JOIN users u ON a.user_id = u.id LEFT JOIN courses c ON a.course_id = c.id ORDER BY a.due_date ASC, a.id ASC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
$resourceRows = $conn->query("SELECT r.id, r.title, r.type, r.is_private, CONCAT(u.first_name, ' ', u.last_name) AS owner, r.file_path, r.url FROM resources r JOIN users u ON r.user_id = u.id ORDER BY r.id DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
$courseRows = $conn->query("SELECT c.id, c.course_code, c.course_name, CONCAT(u.first_name, ' ', u.last_name) AS owner FROM courses c JOIN users u ON c.user_id = u.id ORDER BY c.course_code ASC")->fetch_all(MYSQLI_ASSOC);
$groupRows = $conn->query("SELECT sg.id, sg.name, sg.course_code, CONCAT(u.first_name, ' ', u.last_name) AS owner FROM study_groups sg JOIN users u ON sg.created_by = u.id ORDER BY sg.name ASC")->fetch_all(MYSQLI_ASSOC);
$eventRows = $conn->query("SELECT e.id, e.title, e.start_time, CONCAT(u.first_name, ' ', u.last_name) AS owner FROM schedule_events e JOIN users u ON e.user_id = u.id ORDER BY e.start_time ASC LIMIT 50")->fetch_all(MYSQLI_ASSOC);
$urgent = $conn->query("SELECT COUNT(*) AS c FROM assignments WHERE status = 'pending' AND due_date <= DATE_ADD(NOW(), INTERVAL 3 DAY)")->fetch_assoc()['c'];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>StudySync Admin</title>
  <link rel="stylesheet" href="assets/styles.css">
</head>
<body class="page-admin">
<aside class="sidebar">
  <a class="sidebar-logo" href="dashboard.php"><img src="assets/Studysync.png" alt="StudySync"></a>
  <div class="sidebar-section">Overview</div>
  <a class="sidebar-item" href="dashboard.php"><span class="icon">🏠</span> Dashboard</a>
  <a class="sidebar-item" href="assignments.php"><span class="icon">📝</span> Assignments <?php if($urgent > 0): ?><span class="sidebar-badge"><?=$urgent?></span><?php endif; ?></a>
  <a class="sidebar-item" href="schedule.php"><span class="icon">📅</span> Schedule</a>
  <div class="sidebar-section">Workspace</div>
  <a class="sidebar-item" href="study-groups.php"><span class="icon">👥</span> Study Groups</a>
  <a class="sidebar-item" href="resources.php"><span class="icon">📚</span> Resources</a>
  <a class="sidebar-item" href="gpa.php"><span class="icon">🎯</span> GPA Calculator</a>
  <a class="sidebar-item" href="profile.php"><span class="icon">👤</span> Profile</a>
  <a class="sidebar-item active" href="admin.php"><span class="icon">🛠️</span> Admin</a>
  <div class="sidebar-footer">
    <div class="user-mini">
      <div class="avatar"><?=$init?></div>
      <div class="user-info">
        <strong><?=htmlspecialchars($user['first_name'].' '.$user['last_name'])?></strong>
        <span><?=htmlspecialchars($user['account_role'] ?? 'admin')?></span>
      </div>
    </div>
    <a class="logout-link" href="logout.php">↪ Logout</a>
  </div>
</aside>

<main class="main">
  <div class="page-header">
    <div>
      <h1>Administrator Controls</h1>
      <p>Manage users, assignments, resources, courses, study groups, and schedule records from one page.</p>
    </div>
  </div>

  <?php if($message): ?><div class="flash success"><?=htmlspecialchars($message)?></div><?php endif; ?>
  <?php if($error): ?><div class="flash error"><?=htmlspecialchars($error)?></div><?php endif; ?>

  <div class="admin-grid top-cards">
    <div class="stat-card"><strong><?=count($userRows)?></strong><span>Users</span></div>
    <div class="stat-card"><strong><?=count($assignmentRows)?></strong><span>Assignments loaded</span></div>
    <div class="stat-card"><strong><?=count($resourceRows)?></strong><span>Resources loaded</span></div>
    <div class="stat-card"><strong><?=count($eventRows)?></strong><span>Schedule items loaded</span></div>
  </div>

  <section class="admin-panel">
    <div class="panel-head"><h2>User Accounts</h2><p>Promote, demote, or remove accounts.</p></div>
    <div class="admin-table">
      <div class="admin-row admin-head"><span>User</span><span>Programme</span><span>Role</span><span>Actions</span></div>
      <?php foreach($userRows as $row): ?>
      <div class="admin-row">
        <span><strong><?=htmlspecialchars($row['first_name'].' '.$row['last_name'])?></strong><small><?=htmlspecialchars($row['email'])?></small></span>
        <span><?=htmlspecialchars($row['programme'] ?: 'Not set')?></span>
        <span><span class="pill <?=($row['account_role'] ?? 'student') === 'admin' ? 'admin' : 'student'?>"><?=htmlspecialchars($row['account_role'] ?? 'student')?></span></span>
        <span class="action-cell">
          <form method="post" class="inline-form"><?php csrfField(); ?><input type="hidden" name="action" value="set_role"><input type="hidden" name="user_id" value="<?=$row['id']?>"><select name="account_role"><option value="student" <?=($row['account_role'] ?? 'student') === 'student' ? 'selected' : ''?>>Student</option><option value="admin" <?=($row['account_role'] ?? 'student') === 'admin' ? 'selected' : ''?>>Admin</option></select><button class="btn-small">Save</button></form>
          <form method="post" class="inline-form" onsubmit="return confirm('Delete this user and related data?')"><?php csrfField(); ?><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?=$row['id']?>"><button class="btn-small danger">Delete</button></form>
        </span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="admin-panel">
    <div class="panel-head"><h2>Assignments</h2><p>Update assignment status and priority, or remove records.</p></div>
    <div class="admin-table">
      <div class="admin-row admin-head wide"><span>Assignment</span><span>Owner</span><span>Due</span><span>Controls</span></div>
      <?php foreach($assignmentRows as $row): ?>
      <div class="admin-row wide">
        <span><strong><?=htmlspecialchars($row['title'])?></strong><small><?=htmlspecialchars($row['course_code'] ?: 'No course')?></small></span>
        <span><?=htmlspecialchars($row['owner'])?></span>
        <span><?=date('M j, Y g:i A', strtotime($row['due_date']))?></span>
        <span class="action-cell">
          <form method="post" class="inline-form"><?php csrfField(); ?><input type="hidden" name="action" value="update_assignment"><input type="hidden" name="assignment_id" value="<?=$row['id']?>"><select name="status"><option value="pending" <?=$row['status']==='pending'?'selected':''?>>Pending</option><option value="completed" <?=$row['status']==='completed'?'selected':''?>>Completed</option></select><select name="priority"><option value="low" <?=$row['priority']==='low'?'selected':''?>>Low</option><option value="medium" <?=$row['priority']==='medium'?'selected':''?>>Medium</option><option value="high" <?=$row['priority']==='high'?'selected':''?>>High</option></select><button class="btn-small">Update</button></form>
          <form method="post" class="inline-form" onsubmit="return confirm('Delete this assignment?')"><?php csrfField(); ?><input type="hidden" name="action" value="delete_assignment"><input type="hidden" name="assignment_id" value="<?=$row['id']?>"><button class="btn-small danger">Delete</button></form>
        </span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="admin-panel">
    <div class="panel-head"><h2>Resources</h2><p>Rename resources, change visibility, or remove broken items.</p></div>
    <div class="admin-table">
      <div class="admin-row admin-head wide"><span>Resource</span><span>Owner</span><span>Access</span><span>Controls</span></div>
      <?php foreach($resourceRows as $row): ?>
      <div class="admin-row wide">
        <span><strong><?=htmlspecialchars($row['title'])?></strong><small><?=htmlspecialchars($row['file_path'] ?: $row['url'] ?: 'No file linked')?></small></span>
        <span><?=htmlspecialchars($row['owner'])?></span>
        <span><?=($row['is_private'] ? 'Private' : 'Shared')?> / <?=htmlspecialchars($row['type'])?></span>
        <span class="action-cell">
          <form method="post" class="inline-form"><?php csrfField(); ?><input type="hidden" name="action" value="update_resource"><input type="hidden" name="resource_id" value="<?=$row['id']?>"><input type="text" name="title" value="<?=htmlspecialchars($row['title'])?>" maxlength="150"><select name="type"><option value="pdf" <?=$row['type']==='pdf'?'selected':''?>>PDF</option><option value="image" <?=$row['type']==='image'?'selected':''?>>Image</option><option value="link" <?=$row['type']==='link'?'selected':''?>>Link</option><option value="doc" <?=$row['type']==='doc'?'selected':''?>>Document</option><option value="slides" <?=$row['type']==='slides'?'selected':''?>>Slides</option><option value="other" <?=$row['type']==='other'?'selected':''?>>Other</option></select><label class="inline-check"><input type="checkbox" name="is_private" value="1" <?=$row['is_private'] ? 'checked' : ''?>> Private</label><button class="btn-small">Save</button></form>
          <form method="post" class="inline-form" onsubmit="return confirm('Delete this resource?')"><?php csrfField(); ?><input type="hidden" name="action" value="delete_resource"><input type="hidden" name="resource_id" value="<?=$row['id']?>"><button class="btn-small danger">Delete</button></form>
        </span>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <div class="admin-grid lower-grid">
    <section class="admin-panel compact">
      <div class="panel-head"><h2>Courses</h2><p>Remove course records.</p></div>
      <?php foreach($courseRows as $row): ?>
      <div class="compact-row"><div><strong><?=htmlspecialchars($row['course_code'])?></strong><small><?=htmlspecialchars($row['course_name'])?> · <?=htmlspecialchars($row['owner'])?></small></div><form method="post" onsubmit="return confirm('Delete this course?')"><?php csrfField(); ?><input type="hidden" name="action" value="delete_course"><input type="hidden" name="course_id" value="<?=$row['id']?>"><button class="btn-small danger">Delete</button></form></div>
      <?php endforeach; ?>
    </section>

    <section class="admin-panel compact">
      <div class="panel-head"><h2>Study Groups</h2><p>Remove study groups and memberships.</p></div>
      <?php foreach($groupRows as $row): ?>
      <div class="compact-row"><div><strong><?=htmlspecialchars($row['name'])?></strong><small><?=htmlspecialchars($row['course_code'])?> · <?=htmlspecialchars($row['owner'])?></small></div><form method="post" onsubmit="return confirm('Delete this study group?')"><?php csrfField(); ?><input type="hidden" name="action" value="delete_group"><input type="hidden" name="group_id" value="<?=$row['id']?>"><button class="btn-small danger">Delete</button></form></div>
      <?php endforeach; ?>
    </section>

    <section class="admin-panel compact">
      <div class="panel-head"><h2>Schedule Events</h2><p>Remove calendar records.</p></div>
      <?php foreach($eventRows as $row): ?>
      <div class="compact-row"><div><strong><?=htmlspecialchars($row['title'])?></strong><small><?=date('M j, Y g:i A', strtotime($row['start_time']))?> · <?=htmlspecialchars($row['owner'])?></small></div><form method="post" onsubmit="return confirm('Delete this schedule event?')"><?php csrfField(); ?><input type="hidden" name="action" value="delete_event"><input type="hidden" name="event_id" value="<?=$row['id']?>"><button class="btn-small danger">Delete</button></form></div>
      <?php endforeach; ?>
    </section>
  </div>
</main>
</body>
</html>
