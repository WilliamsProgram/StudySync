<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfOrFail();
}

requireLogin();
$user = getUser($conn);
$uid  = (int) $_SESSION['user_id'];
$init = initials($user['first_name'], $user['last_name']);

$courseError = '';
$courseSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    $code = cleanCourseCode($_POST['course_code'] ?? '', 30);
    $name = cleanText($_POST['course_name'] ?? '', 120);
    $cred = cleanInt($_POST['credits'] ?? 3, 0, 12);
    $lec  = cleanText($_POST['lecturer'] ?? '', 120);
    $col  = normalizeHexColor($_POST['color'] ?? '#4f8ef7');

    if ($code === '' || $name === '') {
        $courseError = 'Course code and course name are required.';
    } else {
        $check = $conn->prepare('SELECT id FROM courses WHERE user_id = ? AND course_code = ? LIMIT 1');
        $check->bind_param('is', $uid, $code);
        $existing = fetchSingleRow($check);

        if ($existing) {
            $courseError = 'That course code already exists in your course list.';
        } else {
            $stmt = $conn->prepare('INSERT INTO courses (user_id, course_code, course_name, credits, lecturer, color) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('ississ', $uid, $code, $name, $cred, $lec, $col);
            $stmt->execute();
            $stmt->close();
            $courseSuccess = 'Course added successfully.';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
    $id   = cleanInt($_POST['edit_id'] ?? 0, 1);
    $code = cleanCourseCode($_POST['course_code'] ?? '', 30);
    $name = cleanText($_POST['course_name'] ?? '', 120);
    $cred = cleanInt($_POST['credits'] ?? 3, 0, 12);
    $lec  = cleanText($_POST['lecturer'] ?? '', 120);
    $col  = normalizeHexColor($_POST['color'] ?? '#4f8ef7');

    if ($id <= 0 || $code === '' || $name === '') {
        $courseError = 'Please enter a valid course code and course name.';
    } else {
        $check = $conn->prepare('SELECT id FROM courses WHERE user_id = ? AND course_code = ? AND id != ? LIMIT 1');
        $check->bind_param('isi', $uid, $code, $id);
        $existing = fetchSingleRow($check);

        if ($existing) {
            $courseError = 'Another course already uses that course code.';
        } else {
            $stmt = $conn->prepare('UPDATE courses SET course_code = ?, course_name = ?, credits = ?, lecturer = ?, color = ? WHERE id = ? AND user_id = ?');
            $stmt->bind_param('ssissii', $code, $name, $cred, $lec, $col, $id, $uid);
            $stmt->execute();
            $stmt->close();
            redirectTo('courses.php');
        }
    }
}

if (isset($_GET['delete'])) {
    $id = cleanInt($_GET['delete'] ?? 0, 1);
    if ($id > 0) {
        $stmt = $conn->prepare('DELETE FROM courses WHERE id = ? AND user_id = ?');
        $stmt->bind_param('ii', $id, $uid);
        $stmt->execute();
        $stmt->close();
    }
    redirectTo('courses.php');
}

$editData = null;
if (isset($_GET['edit'])) {
    $id = cleanInt($_GET['edit'] ?? 0, 1);
    if ($id > 0) {
        $stmt = $conn->prepare('SELECT * FROM courses WHERE id = ? AND user_id = ? LIMIT 1');
        $stmt->bind_param('ii', $id, $uid);
        $editData = fetchSingleRow($stmt);
    }
}

$stmt = $conn->prepare(
    'SELECT c.*,
        (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id AND a.user_id = ?) AS total_assignments,
        (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id AND a.user_id = ? AND a.status = "completed") AS completed_assignments,
        (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id AND a.user_id = ? AND a.status = "pending") AS pending_assignments,
        (SELECT MIN(a.due_date) FROM assignments a WHERE a.course_id = c.id AND a.user_id = ? AND a.status = "pending") AS next_due,
        (SELECT COUNT(*) FROM resources r WHERE r.course_id = c.id AND r.user_id = ?) AS total_resources,
        (SELECT COUNT(*) FROM study_groups g WHERE g.course_code = c.course_code AND g.created_by = ?) AS total_groups
     FROM courses c
     WHERE c.user_id = ?
     ORDER BY c.course_code ASC'
);
$stmt->bind_param('iiiiiii', $uid, $uid, $uid, $uid, $uid, $uid, $uid);
$courseRows = fetchAllRows($stmt);

$stmt = $conn->prepare("SELECT COUNT(*) AS c FROM assignments WHERE user_id = ? AND status = 'pending' AND due_date <= DATE_ADD(NOW(), INTERVAL 3 DAY)");
$stmt->bind_param('i', $uid);
$urgent = (int) fetchScalar($stmt, 'c', 0);

$totalCourses = count($courseRows);
$totalCredits = 0;
$totalPendingAssignments = 0;
$totalResources = 0;
$totalCompletedAssignments = 0;
$totalAssignments = 0;
foreach ($courseRows as $row) {
    $totalCredits += (int) $row['credits'];
    $totalPendingAssignments += (int) $row['pending_assignments'];
    $totalResources += (int) $row['total_resources'];
    $totalCompletedAssignments += (int) $row['completed_assignments'];
    $totalAssignments += (int) $row['total_assignments'];
}
$overallProgress = $totalAssignments > 0 ? (int) round(($totalCompletedAssignments / $totalAssignments) * 100) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Courses — StudySync</title>
<link rel="stylesheet" href="assets/styles.css">
</head>
<body class="page-courses">
<aside class="sidebar">
  <a class="sidebar-logo" href="dashboard.php" aria-label="Go to dashboard"><img src="assets/Studysync.png" alt="StudySync logo"></a>
  <div class="sidebar-section">Main</div>
  <a class="sidebar-item" href="dashboard.php"><span class="icon">🏠</span> Dashboard</a>
  <a class="sidebar-item active" href="courses.php"><span class="icon">📘</span> Courses</a>
  <a class="sidebar-item" href="assignments.php"><span class="icon">📚</span> Assignments <?php if($urgent>0): ?><span class="sidebar-badge"><?=$urgent?></span><?php endif; ?></a>
  <a class="sidebar-item" href="schedule.php"><span class="icon">🗓️</span> Schedule</a>
  <div style="margin-top:1rem"></div>
  <div class="sidebar-section">Collaborate</div>
  <a class="sidebar-item" href="study-groups.php"><span class="icon">👥</span> Study Groups</a>
  <a class="sidebar-item" href="resources.php"><span class="icon">📁</span> Resources</a>
  <div style="margin-top:1rem"></div>
  <div class="sidebar-section">Tools</div>
  <a class="sidebar-item" href="gpa.php"><span class="icon">🎯</span> GPA Calculator</a>
  <a class="sidebar-item" href="profile.php"><span class="icon">👤</span> Profile</a>
  <?= adminSidebarLink($user) ?>
  <a class="logout-link" href="logout.php"><span class="icon">🚪</span> Log Out</a>
  <div class="sidebar-footer">
    <div class="user-mini"><div class="avatar"><?= $init ?></div><div class="user-info"><strong><?= htmlspecialchars($user['first_name'].' '.$user['last_name']) ?></strong><span><?= htmlspecialchars($user['year'] ?? 'Student') ?></span></div></div>
  </div>
</aside>

<main class="main">
  <div class="page-header">
    <div>
      <h1>Courses</h1>
      <p class="page-subtitle">Manage your class list and see course-linked progress in one place.</p>
    </div>
    <button class="btn-primary" onclick="openModal('add')">+ Add Course</button>
  </div>

  <?php if($courseError !== ''): ?><div class="error-msg">⚠ <?= htmlspecialchars($courseError) ?></div><?php endif; ?>
  <?php if($courseSuccess !== ''): ?><div class="success-msg">✅ <?= htmlspecialchars($courseSuccess) ?></div><?php endif; ?>

  <div class="course-stat-grid">
    <div class="course-stat-card"><span class="course-stat-label">Total Courses</span><strong><?= $totalCourses ?></strong></div>
    <div class="course-stat-card"><span class="course-stat-label">Credit Hours</span><strong><?= $totalCredits ?></strong></div>
    <div class="course-stat-card"><span class="course-stat-label">Pending Tasks</span><strong><?= $totalPendingAssignments ?></strong></div>
    <div class="course-stat-card"><span class="course-stat-label">Overall Progress</span><strong><?= $overallProgress ?>%</strong></div>
  </div>

  <div class="card">
    <div class="card-header">
      <span class="card-title">Course Tracker</span>
      <span class="card-action">Resources linked: <?= $totalResources ?></span>
    </div>

    <?php if (!$courseRows): ?>
      <div class="empty-state">No courses added yet. <a href="#" onclick="openModal('add'); return false;" style="color:var(--accent)">Add your first course.</a></div>
    <?php else: ?>
      <div class="courses-grid">
        <?php foreach ($courseRows as $course):
          $total = (int) $course['total_assignments'];
          $completed = (int) $course['completed_assignments'];
          $pending = (int) $course['pending_assignments'];
          $progress = $total > 0 ? (int) round(($completed / $total) * 100) : 0;
          $nextDue = $course['next_due'];
        ?>
        <div class="course-card">
          <div class="course-card-top">
            <div>
              <div class="course-code-row">
                <span class="course-dot" style="background:<?= e($course['color']) ?>"></span>
                <span class="course-code"><?= e($course['course_code']) ?></span>
              </div>
              <h3><?= e($course['course_name']) ?></h3>
              <div class="course-meta"><?= (int) $course['credits'] ?> credits<?= $course['lecturer'] ? ' · ' . e($course['lecturer']) : '' ?></div>
            </div>
            <div class="course-actions">
              <a href="assignments.php?search=<?= urlencode($course['course_code']) ?>" class="act-btn">Assignments</a>
              <a href="?edit=<?= (int) $course['id'] ?>" class="act-btn">Edit</a>
              <a href="?delete=<?= (int) $course['id'] ?>" class="act-btn danger" onclick="return confirm('Delete this course? Related items with course links may remain without a course.')">Delete</a>
            </div>
          </div>

          <div class="course-metrics">
            <div class="metric-pill"><strong><?= $total ?></strong><span>Total tasks</span></div>
            <div class="metric-pill"><strong><?= $pending ?></strong><span>Pending</span></div>
            <div class="metric-pill"><strong><?= (int) $course['total_resources'] ?></strong><span>Resources</span></div>
            <div class="metric-pill"><strong><?= (int) $course['total_groups'] ?></strong><span>Groups</span></div>
          </div>

          <div class="progress-header">
            <span>Completion progress</span>
            <span><?= $progress ?>%</span>
          </div>
          <div class="progress-bar"><div class="progress-fill" style="width:<?= $progress ?>%;background:<?= e($course['color']) ?>"></div></div>

          <div class="course-footer-row">
            <span class="course-next-due">Next due: <?= $nextDue ? date('M j, Y g:i A', strtotime($nextDue)) : 'No pending assignments' ?></span>
            <a href="resources.php" class="mini-link">Resources →</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>

<div class="modal-overlay" id="addModal" onclick="if(event.target===this)closeModal('add')">
  <div class="modal">
    <h3>Add Course</h3>
    <form method="POST" action="courses.php">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="add">
      <div class="fg-row">
        <div class="fg"><label>Course Code *</label><input type="text" name="course_code" placeholder="e.g. CPTR304" required></div>
        <div class="fg"><label>Course Name *</label><input type="text" name="course_name" placeholder="e.g. Internet Authoring" required></div>
      </div>
      <div class="fg-row">
        <div class="fg"><label>Credits</label><input type="number" name="credits" value="3" min="0" max="12"></div>
        <div class="fg"><label>Lecturer</label><input type="text" name="lecturer" placeholder="e.g. Dr. Brown"></div>
      </div>
      <div class="fg"><label>Colour</label><input type="color" name="color" value="#4f8ef7" style="height:42px;padding:0.3rem;"></div>
      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeModal('add')">Cancel</button>
        <button type="submit" class="btn-primary">Save Course</button>
      </div>
    </form>
  </div>
</div>

<div class="modal-overlay" id="editModal" onclick="if(event.target===this)closeModal('edit')">
  <div class="modal">
    <h3>Edit Course</h3>
    <form method="POST" action="courses.php">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="edit_id" value="<?= $editData['id'] ?? '' ?>">
      <div class="fg-row">
        <div class="fg"><label>Course Code *</label><input type="text" name="course_code" value="<?= e($editData['course_code'] ?? '') ?>" required></div>
        <div class="fg"><label>Course Name *</label><input type="text" name="course_name" value="<?= e($editData['course_name'] ?? '') ?>" required></div>
      </div>
      <div class="fg-row">
        <div class="fg"><label>Credits</label><input type="number" name="credits" value="<?= e($editData['credits'] ?? 3) ?>" min="0" max="12"></div>
        <div class="fg"><label>Lecturer</label><input type="text" name="lecturer" value="<?= e($editData['lecturer'] ?? '') ?>"></div>
      </div>
      <div class="fg"><label>Colour</label><input type="color" name="color" value="<?= e($editData['color'] ?? '#4f8ef7') ?>" style="height:42px;padding:0.3rem;"></div>
      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeModal('edit')">Cancel</button>
        <button type="submit" class="btn-primary">Update Course</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(type){document.getElementById(type+'Modal').classList.add('open');}
function closeModal(type){document.getElementById(type+'Modal').classList.remove('open');}
<?php if($editData): ?>
document.addEventListener('DOMContentLoaded',()=>openModal('edit'));
<?php endif; ?>
</script>
</body>
</html>
