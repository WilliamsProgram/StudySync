<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Privacy Policy — StudySync</title>
<link rel="stylesheet" href="assets/styles.css">
</head>
<body class="page-legal">
  <div class="legal-shell">
    <div class="legal-top">
      <a class="sidebar-logo" href="index.php" aria-label="Go to dashboard"><img src="assets/Studysync.png" alt="StudySync logo"></a>
      <a href="register.php" class="btn-secondary">Back to registration</a>
    </div>
    <div class="legal-card">
      <h1>Privacy Policy</h1>
      <p>StudySync stores the information needed to provide student planning features, including account details, assignments, timetable events, grades, study groups, and shared resources uploaded by the user.</p>
      <h2>Information collected</h2>
      <p>The application stores your name, email, student details, profile content, course records, deadlines, schedule events, and files that you choose to upload.</p>
      <h2>How the data is used</h2>
      <p>Your data is used to support login, planning tools, reminders, collaboration features, and personal tracking inside the application.</p>
      <h2>Sharing</h2>
      <p>Resources and study group messages are only shared within the groups or pages where you choose to place them.</p>
      <h2>Storage and protection</h2>
      <p>The system uses server-side validation, sanitised inputs, and database-backed storage. Users should still avoid uploading sensitive information that is not needed for coursework.</p>
      <h2>User choices</h2>
      <p>You may update your profile information, manage your content, and control what you upload to the platform.</p>
    </div>
  </div>
</body>
</html>
