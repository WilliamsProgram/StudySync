<?php
require_once 'config.php';
requireLogin();

$user = getUser($conn);
$isAdmin = isAdminUser($user);
$uid = (int) $user['id'];
$resourceId = cleanInt($_GET['id'] ?? 0, 1);
$mode = ($_GET['mode'] ?? 'view') === 'download' ? 'download' : 'view';

if ($resourceId <= 0) {
    http_response_code(404);
    exit('Resource not found.');
}

$stmt = $conn->prepare('SELECT id, user_id, title, file_path, is_private FROM resources WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $resourceId);
$resource = fetchSingleRow($stmt);

if (!$resource || empty($resource['file_path'])) {
    http_response_code(404);
    exit('File not found.');
}

$canAccess = $isAdmin || (int) $resource['user_id'] === $uid || (int) $resource['is_private'] === 0;
if (!$canAccess) {
    http_response_code(403);
    exit('You do not have permission to open this file.');
}

$safePath = safeUploadedResourcePath($resource['file_path']);
if (!$safePath || !file_exists($safePath)) {
    http_response_code(404);
    exit('Stored file is missing.');
}

$mimeType = mime_content_type($safePath) ?: 'application/octet-stream';
$downloadName = basename($safePath);
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($safePath));
header('X-Content-Type-Options: nosniff');
$disposition = $mode === 'download' ? 'attachment' : 'inline';
header('Content-Disposition: ' . $disposition . '; filename="' . rawurlencode($downloadName) . '"');
readfile($safePath);
exit;
