<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Terms of Service — StudySync</title>
<link rel="stylesheet" href="assets/styles.css">
</head>
<body class="page-legal">
  <div class="legal-shell">
    <div class="legal-top">
      <a class="sidebar-logo" href="index.php" aria-label="Go to dashboard"><img src="assets/Studysync.png" alt="StudySync logo"></a>
      <a href="register.php" class="btn-secondary">Back to registration</a>
    </div>
    <div class="legal-card">
      <h1>Terms of Service</h1>
      <p>StudySync is a student planning web app that stores timetable entries, assignments, study groups, grades, and shared resources for the signed in user.</p>
      <h2>Account use</h2>
      <p>You are responsible for the accuracy of the details entered into your account and for keeping your login information private.</p>
      <h2>Acceptable use</h2>
      <p>You may use the platform for academic planning, collaboration, and personal study support. You must not upload harmful files, false information, or content that affects other users.</p>
      <h2>Content ownership</h2>
      <p>You keep ownership of the files and text you upload. By storing them in the system, you allow the application to save, display, and organise that content for your account and your selected group members.</p>
      <h2>Service limits</h2>
      <p>The application is provided as part of the project work. Access, storage, and features may be updated as the project develops.</p>
      <h2>Account removal</h2>
      <p>An account may be removed if it is used in a way that harms the system, other users, or the stored data.</p>
    </div>
  </div>
</body>
</html>
